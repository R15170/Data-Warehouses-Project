-- Task2 : For retreving all the tables ( Releation Names )
SELECT owner,
       table_name
FROM all_tables
WHERE owner IN (
    'DWT_BRANCH_1',
    'DWT_BRANCH_4',
    'DWT_BRANCH_5'
)
ORDER BY owner, table_name;

-- Task2: For all the column names and data types in the columns
SELECT
    owner,
    table_name,
    column_name,
    data_type,
    data_length,
    data_precision,
    data_scale,
    nullable
FROM all_tab_columns
WHERE owner = 'DWT_BRANCH_1'
ORDER BY table_name, column_id;

SELECT
    owner,
    table_name,
    column_name,
    data_type,
    data_length,
    data_precision,
    data_scale,
    nullable
FROM all_tab_columns
WHERE owner = 'DWT_BRANCH_4'
ORDER BY table_name, column_id;

SELECT
    owner,
    table_name,
    column_name,
    data_type,
    data_length,
    data_precision,
    data_scale,
    nullable
FROM all_tab_columns
WHERE owner = 'DWT_BRANCH_5'
ORDER BY table_name, column_id;

-- Task2 : For all the integretiy contraints like Primary Keys and foreign keys
SELECT
    c.table_name,
    cc.column_name,
    c.constraint_name,
    c.constraint_type
FROM all_constraints c,
     all_cons_columns cc
WHERE c.owner = cc.owner
  AND c.constraint_name = cc.constraint_name
  AND c.owner = 'DWT_BRANCH_1'
ORDER BY c.table_name;

SELECT
    c.table_name,
    cc.column_name,
    c.constraint_name,
    c.constraint_type
FROM all_constraints c,
     all_cons_columns cc
WHERE c.owner = cc.owner
  AND c.constraint_name = cc.constraint_name
  AND c.owner = 'DWT_BRANCH_4'
ORDER BY c.table_name;

SELECT
    c.table_name,
    cc.column_name,
    c.constraint_name,
    c.constraint_type
FROM all_constraints c,
     all_cons_columns cc
WHERE c.owner = cc.owner
  AND c.constraint_name = cc.constraint_name
  AND c.owner = 'DWT_BRANCH_5'
ORDER BY c.table_name;
/*
Task3 : All the Create statements that may have been used to create all the tables in 
different branches 
*/
-- For all the tables of Branch 1
CREATE TABLE DWT_BRANCH_1.CUSTOMER (
    ID NUMBER(11,0),
    NAME VARCHAR2(40 BYTE),
    SURNAME VARCHAR2(40 BYTE),
    STR VARCHAR2(60 BYTE),
    NO VARCHAR2(5 BYTE),
    ZIP VARCHAR2(5 BYTE),
    PLACE VARCHAR2(50 BYTE),
    GEND CHAR(1 BYTE),
    BDAY DATE,

    CONSTRAINT SYS_C0020056
        PRIMARY KEY (ID)
);

CREATE TABLE DWT_BRANCH_1.PRODUCTS (
    ID NUMBER(11,0),
    NAME VARCHAR2(50 BYTE),
    SORT VARCHAR2(20 BYTE),
    SZ NUMBER(3,2),
    PRICE NUMBER(3,2),

    CONSTRAINT SYS_C0020061
        PRIMARY KEY (ID)
);

CREATE TABLE DWT_BRANCH_1."ORDER" (
    "ORDER" VARCHAR2(15 BYTE),
    "DATE" DATE,
    AMOUNT CHAR(5 BYTE),
    CSTMR NUMBER(11,0),
    PRO NUMBER(11,0),

    CONSTRAINT SYS_C0020051
        UNIQUE (PRO, CSTMR, "DATE"),

    CONSTRAINT SYS_C0020062
        FOREIGN KEY (CSTMR)
        REFERENCES DWT_BRANCH_1.CUSTOMER(ID),

    CONSTRAINT SYS_C0020205
        FOREIGN KEY (PRO)
        REFERENCES DWT_BRANCH_1.PRODUCTS(ID)
);


-- Tabels for branch 4 
CREATE TABLE DWT_BRANCH_4.CUSTOMER (
    CUSTUMERNUMBER NUMBER(10,0),
    NAME VARCHAR2(30 BYTE),
    FIRSTNAME VARCHAR2(30 BYTE),
    STREET_NO VARCHAR2(40 BYTE),
    ZIP NUMBER(5,0),
    PLACE VARCHAR2(30 BYTE),
    GENDER CHAR(1 BYTE),
    BDAY DATE,

    CONSTRAINT SYS_C0020163
        PRIMARY KEY (CUSTUMERNUMBER)
);

CREATE TABLE DWT_BRANCH_4.SORT (
    SORTNUMBER NUMBER(3,0),
    NAME VARCHAR2(25 BYTE),

    CONSTRAINT SYS_C0020174
        PRIMARY KEY (SORTNUMBER)
);

CREATE TABLE DWT_BRANCH_4.PRODUCT (
    PRODUCTNUMBER NUMBER(12,0),
    NAME VARCHAR2(30 BYTE),
    SID NUMBER(5,0),
    "SIZE" VARCHAR2(20 BYTE),
    PRICE NUMBER(3,2),

    CONSTRAINT SYS_C0020172
        PRIMARY KEY (PRODUCTNUMBER)
);

CREATE TABLE DWT_BRANCH_4."ORDER" (
    ORDERID NUMBER(13,0),
    CID NUMBER(10,0),
    "DATE" DATE,

    CONSTRAINT SYS_C0020159
        PRIMARY KEY (ORDERID)
);

CREATE TABLE DWT_BRANCH_4.ITEM (
    OID NUMBER(13,0),
    AMOUNT NUMBER(5,0),
    PID NUMBER(12,0),

    CONSTRAINT SYS_C0020167
        PRIMARY KEY (OID, AMOUNT, PID)
);

-- Tables for branch 5
CREATE TABLE DWT_BRANCH_5.PLACE (
    ZIP CHAR(5 BYTE),
    PLACE VARCHAR2(30 BYTE),

    CONSTRAINT SYS_C0020184
        PRIMARY KEY (ZIP)
);

CREATE TABLE DWT_BRANCH_5.CUSTOMER (
    ID NUMBER(10,0),
    NAME VARCHAR2(30 BYTE),
    SURNAME VARCHAR2(30 BYTE),
    STR VARCHAR2(40 BYTE),
    NO NUMBER(3,1),
    ZIP CHAR(5 BYTE),
    GEND CHAR(1 BYTE),
    BDAY DATE,

    CONSTRAINT SYS_C0020189
        FOREIGN KEY (ZIP)
        REFERENCES DWT_BRANCH_5.PLACE(ZIP)
);

CREATE TABLE DWT_BRANCH_5."ORDER" (
    OID VARCHAR2(30 BYTE),
    "DATE" DATE,
    CUSTOMER VARCHAR2(50 BYTE),

    CONSTRAINT SYS_C0020178
        PRIMARY KEY (OID)
);
CREATE TABLE DWT_BRANCH_5.ORDERS (
    "ORDER" VARCHAR2(30 BYTE),
    PRODUCT NUMBER(10,0),
    AMOUNT NUMBER(2,0)
);

CREATE TABLE DWT_BRANCH_5.PRODUCT (
    ID NUMBER(10,0),
    NAME VARCHAR2(30 BYTE),
    SORT VARCHAR2(25 BYTE),
    SZ NUMBER(3,2),
    PRICE NUMBER(3,2),

    CONSTRAINT SYS_C0020188
        UNIQUE (ID)
);



