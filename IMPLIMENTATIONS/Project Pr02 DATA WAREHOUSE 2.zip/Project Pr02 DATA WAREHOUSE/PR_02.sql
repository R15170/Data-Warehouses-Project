-- Dimension Customers
CREATE TABLE Customers (
    Customer_ID INT PRIMARY KEY,
    First_Name VARCHAR(50),
    Family_Name VARCHAR(50),
    Street_No VARCHAR(100),
    House_No VARCHAR(20),
    ZIP_Code VARCHAR(10),
    City VARCHAR(50),
    Birth_Date DATE,
    Age_Group VARCHAR(20),
    Gender VARCHAR(10)
);
-- Dimension Product
CREATE TABLE Product (
    Product_ID INT PRIMARY KEY,
    Product_Name VARCHAR(100),
    Product_Type VARCHAR(50)
);
-- Dimesion Branch
CREATE TABLE Branch (
    Branch_ID INT PRIMARY KEY,
    Branch VARCHAR(50),
    Region VARCHAR(50)
);
-- Dimension Time
CREATE TABLE Time (
    Time_ID INT PRIMARY KEY,
    Day INT,
    Month INT,
    Quarter INT,
    Year INT,
    Week INT
);
-- Fact Table Sales
CREATE TABLE Sales (
    Product_ID INT,
    Time_ID INT,
    Branch_ID INT,
    Customer_ID INT,
    Sales_Quantity_Liter DECIMAL(10,2),

    FOREIGN KEY (Product_ID) REFERENCES Product(Product_ID),
    FOREIGN KEY (Time_ID) REFERENCES Time(Time_ID),
    FOREIGN KEY (Branch_ID) REFERENCES Branch(Branch_ID),
    FOREIGN KEY (Customer_ID) REFERENCES Customers(Customer_ID)
);

